#!/usr/bin/env python3
"""
Script de rapport mensuel — version Python.
Génère des statistiques depuis la base SQLite et envoie le rapport.
Ecrit vite, fonctionne, mais difficile à tester et à maintenir.
"""

import sqlite3
import smtplib
import csv
import json
import sys
import os
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


# Variables globales — état partagé
DB_PATH    = os.path.join(os.path.dirname(__file__), '..', 'shopmaster.db')
SMTP_HOST  = 'smtp.monhébergeur.fr'
SMTP_PORT  = 587
SMTP_USER  = 'contact@shopmaster.fr'
SMTP_PASS  = 'Azerty1234!'  # TODO: variable d'env
EMAIL_DEST = 'direction@shopmaster.fr'
conn       = None  # connexion globale


def init():
    global conn
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row


# Fonction qui fait tout : calcule, formate ET envoie
# Primitive Obsession : mois/annee sont des ints bruts sans validation
def faire_rapport(m, a):
    global conn

    # Pas de vérification des paramètres
    debut = f"{a:04d}-{m:02d}-01"
    # Calcul fin du mois artisanal
    if m == 12:
        fin = f"{a+1:04d}-01-01"
    else:
        fin = f"{a:04d}-{m+1:02d}-01"

    # 1. CA — tout dans la même fonction
    r1 = conn.execute("""
        SELECT COALESCE(SUM(total), 0) as ca,
               COUNT(*) as nb,
               COALESCE(AVG(total), 0) as moy
        FROM commandes
        WHERE date_commande >= ? AND date_commande < ?
        AND statut NOT IN ('annulee')
    """, (debut, fin)).fetchone()

    ca  = r1['ca']
    nb  = r1['nb']
    moy = r1['moy']

    # 2. Top produits — même fonction
    tops = conn.execute("""
        SELECT p.nom, p.ref, SUM(cl.quantite) as q,
               SUM(cl.quantite * cl.prix_unitaire) as total
        FROM commande_lignes cl
        JOIN produits p ON p.id = cl.produit_id
        JOIN commandes c ON c.id = cl.commande_id
        WHERE c.date_commande >= ? AND c.date_commande < ?
        AND c.statut != 'annulee'
        GROUP BY p.id ORDER BY total DESC LIMIT 5
    """, (debut, fin)).fetchall()

    # 3. Clients — même fonction
    nc = conn.execute("""
        SELECT COUNT(*) as n FROM users
        WHERE date_inscription >= ? AND date_inscription < ?
    """, (debut, fin)).fetchone()['n']

    # 4. Construire le CSV — même fonction, pas de séparation formatage/données
    lignes_csv = []
    lignes_csv.append(['Métrique', 'Valeur'])
    lignes_csv.append(['CA TTC', f"{ca:.2f} €"])
    lignes_csv.append(['Nb commandes', str(nb)])
    lignes_csv.append(['Panier moyen', f"{moy:.2f} €"])
    lignes_csv.append(['Nouveaux clients', str(nc)])
    lignes_csv.append([])
    lignes_csv.append(['Top produits', '', ''])
    lignes_csv.append(['Ref', 'Nom', 'Qté', 'CA'])
    for t in tops:
        lignes_csv.append([t['ref'], t['nom'], str(t['q']), f"{t['total']:.2f} €"])

    # Ecrire CSV dans un fichier temp — chemin en dur
    chemin = f"/tmp/rapport_{a}_{m:02d}.csv"
    with open(chemin, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerows(lignes_csv)

    # 5. Envoyer l'email — dans la même fonction
    msg = MIMEMultipart()
    msg['From']    = SMTP_USER
    msg['To']      = EMAIL_DEST
    msg['Subject'] = f"Rapport mensuel {m:02d}/{a}"

    corps = f"""Bonjour,

Veuillez trouver ci-joint le rapport mensuel de {m:02d}/{a}.

Résumé :
- CA TTC : {ca:.2f} €
- Commandes : {nb}
- Panier moyen : {moy:.2f} €
- Nouveaux clients : {nc}

Cordialement,
ShopMaster (envoi automatique)"""

    msg.attach(MIMEText(corps, 'plain', 'utf-8'))

    with open(chemin, 'rb') as f:
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename="rapport_{a}_{m:02d}.csv"')
        msg.attach(part)

    # Connexion SMTP — peut planter sans message d'erreur utile
    try:
        smtp = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
        smtp.starttls()
        smtp.login(SMTP_USER, SMTP_PASS)
        smtp.send_message(msg)
        smtp.quit()
        print("Rapport envoyé.")
    except Exception as e:
        print(f"Erreur email : {e}")

    # 6. Aussi sauvegarder en JSON — pourquoi pas, c'est là
    data = {
        'annee': a, 'mois': m,
        'ca': ca, 'nb_commandes': nb, 'panier_moyen': moy,
        'nouveaux_clients': nc,
        'top_produits': [dict(t) for t in tops],
        'genere_le': datetime.now().isoformat(),
    }
    chemin_json = f"/tmp/rapport_{a}_{m:02d}.json"
    with open(chemin_json, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)

    return data


# Analyser les tendances — pas de séparation lecture / calcul / affichage
def analyser_tendances():
    global conn
    # Comparer les 3 derniers mois — logique date hardcodée
    maintenant = datetime.now()
    resultats   = []

    for i in range(3):
        m = maintenant.month - i
        a = maintenant.year
        if m <= 0:
            m += 12
            a -= 1

        r = conn.execute("""
            SELECT COALESCE(SUM(total), 0) as ca, COUNT(*) as nb
            FROM commandes
            WHERE strftime('%Y-%m', date_commande) = ?
            AND statut != 'annulee'
        """, (f"{a:04d}-{m:02d}",)).fetchone()

        resultats.append({'mois': f"{m:02d}/{a}", 'ca': r['ca'], 'nb': r['nb']})

    # Afficher directement — mélange calcul et présentation
    print("\n=== TENDANCES 3 DERNIERS MOIS ===")
    for r in resultats:
        print(f"  {r['mois']} : CA={r['ca']:.2f}€  Commandes={r['nb']}")

    # Calcul variation — pas de gestion du cas zéro
    if len(resultats) >= 2 and resultats[1]['ca'] > 0:
        var = ((resultats[0]['ca'] - resultats[1]['ca']) / resultats[1]['ca']) * 100
        print(f"\nVariation mois M vs M-1 : {var:+.1f}%")

    return resultats


# Script principal — pas de séparation parse args / logique
if __name__ == '__main__':
    init()

    if len(sys.argv) == 3:
        try:
            m = int(sys.argv[1])
            a = int(sys.argv[2])
        except ValueError:
            print("Usage : python rapport_mensuel.py <mois> <annee>")
            sys.exit(1)

        if not (1 <= m <= 12):
            print("Mois invalide")
            sys.exit(1)

        print(f"Génération du rapport {m:02d}/{a}...")
        d = faire_rapport(m, a)
        print(f"CA : {d['ca']:.2f} € | Commandes : {d['nb_commandes']}")
        analyser_tendances()

    elif len(sys.argv) == 1:
        # Rapport du mois courant par défaut
        now = datetime.now()
        faire_rapport(now.month, now.year)
        analyser_tendances()

    else:
        print("Usage : python rapport_mensuel.py [mois annee]")
        sys.exit(1)
