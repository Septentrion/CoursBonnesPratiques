<?php
// Initialise la base avec des données de démonstration
require_once __DIR__ . '/../config/db.php';
global $db;

// Insérer des produits d'exemple
$produits = [
    ['ELEC-001', 'Casque Bluetooth Pro',     89.99, 50, 5, 'electronique'],
    ['ELEC-002', 'Souris ergonomique',        45.00, 30, 3, 'electronique'],
    ['VET-001',  'T-shirt coton bio',         25.00, 100, 10, 'vetements'],
    ['VET-002',  'Jean slim',                 59.90, 40, 5, 'vetements'],
    ['LIVRE-001','Clean Code - R.C. Martin',  35.00, 20, 2, 'livres'],
    ['LIVRE-002','DDD - Eric Evans',          45.00, 15, 2, 'livres'],
    ['ALIM-001', 'Café arabica 500g',          12.90, 200, 20, 'alimentaire'],
];
foreach ($produits as $p) {
    $db->prepare(
        "INSERT OR IGNORE INTO produits (ref, nom, prix, stock, stock_min, actif, tva, categorie)
         VALUES (?, ?, ?, ?, ?, 1, 20, ?)"
    )->execute($p);
}

// Admin de démonstration
$db->prepare(
    "INSERT OR IGNORE INTO users (nom, prenom, email, mdp, role, actif, date_inscription)
     VALUES ('Admin', 'Super', 'admin@shopmaster.fr', ?, 'admin', 1, datetime('now'))"
)->execute([password_hash('admin123', PASSWORD_BCRYPT)]);

// Code promo de démonstration
$db->prepare(
    "INSERT OR IGNORE INTO codes_promo (code, type, valeur, min_commande, actif)
     VALUES ('WELCOME10', 'pourcent', 10, 0, 1)"
)->execute();

echo "Base de données initialisée avec des données de démonstration.\n";
echo "Compte admin : admin@shopmaster.fr / admin123\n";
