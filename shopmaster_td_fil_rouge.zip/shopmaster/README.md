# ShopMaster — Système de gestion de boutique en ligne

Application de gestion de commandes développée en urgence pour répondre
à une demande client. Fonctionne en production depuis 18 mois.

## Prérequis

- PHP 8.0+
- SQLite 3
- Python 3.10+ (pour les scripts de rapport)

## Installation

```bash
# Initialiser la base de données
php scripts/init_db.php

# Lancer le serveur de développement
php -S localhost:8000
```

## Structure

```
config/      Configuration base de données
src/         Classes métier
templates/   Vues HTML
scripts/     Scripts Python (rapports)
tests/       Tests unitaires
```

## Notes développeur

Le code a été écrit vite, il y a des choses à améliorer mais ça marche.
Ne pas toucher à CommandeManager sans demander à Marc.

## TODO

- Ajouter de la validation côté serveur
- Faire des tests pour les remises
- Refactoriser le rapport mensuel (trop lent)
- Gérer les erreurs proprement
