<?php

// Base de données SQLite — ne pas changer le chemin en prod !
$db = new PDO('sqlite:' . __DIR__ . '/../shopmaster.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA foreign_keys = ON');

// Créer les tables si elles n'existent pas
$db->exec("
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT, prenom TEXT, email TEXT, mdp TEXT,
        role TEXT DEFAULT 'client',
        adresse TEXT, ville TEXT, cp TEXT, pays TEXT DEFAULT 'FR',
        tel TEXT, actif INTEGER DEFAULT 1,
        date_inscription TEXT, derniere_connexion TEXT,
        nb_commandes INTEGER DEFAULT 0,
        total_achats REAL DEFAULT 0,
        notes TEXT
    );

    CREATE TABLE IF NOT EXISTS produits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ref TEXT, nom TEXT, description TEXT,
        prix REAL, prix_achat REAL,
        stock INTEGER DEFAULT 0, stock_min INTEGER DEFAULT 5,
        categorie TEXT, sous_categorie TEXT,
        poids REAL, tva REAL DEFAULT 20,
        actif INTEGER DEFAULT 1,
        image TEXT, fournisseur TEXT
    );

    CREATE TABLE IF NOT EXISTS commandes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, ref TEXT,
        statut TEXT DEFAULT 'en_attente',
        total REAL, total_ht REAL, tva_montant REAL,
        remise REAL DEFAULT 0, code_promo TEXT,
        adresse_livraison TEXT, ville_livraison TEXT,
        cp_livraison TEXT, pays_livraison TEXT,
        mode_paiement TEXT, transaction_id TEXT,
        date_commande TEXT, date_envoi TEXT,
        notes TEXT, notes_internes TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS commande_lignes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        commande_id INTEGER, produit_id INTEGER,
        quantite INTEGER, prix_unitaire REAL,
        FOREIGN KEY(commande_id) REFERENCES commandes(id),
        FOREIGN KEY(produit_id) REFERENCES produits(id)
    );

    CREATE TABLE IF NOT EXISTS codes_promo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT, type TEXT,
        valeur REAL, min_commande REAL DEFAULT 0,
        date_debut TEXT, date_fin TEXT,
        nb_utilisations INTEGER DEFAULT 0,
        max_utilisations INTEGER DEFAULT 999,
        actif INTEGER DEFAULT 1
    );
");

// Configuration email (en dur pour l'instant)
define('SMTP_HOST', 'smtp.monhébergeur.fr');
define('SMTP_PORT', 587);
define('SMTP_USER', 'contact@shopmaster.fr');
define('SMTP_PASS', 'Azerty1234!');  // TODO: mettre en variable d'environnement
define('EMAIL_FROM', 'contact@shopmaster.fr');
define('SITE_NOM', 'ShopMaster');
define('SITE_URL', 'https://shopmaster.fr');

// TVA par défaut
define('TVA', 0.20);

// Frais de port
define('FRAIS_PORT_STANDARD', 4.90);
define('FRAIS_PORT_EXPRESS', 9.90);
define('SEUIL_GRATUIT', 50.0);
