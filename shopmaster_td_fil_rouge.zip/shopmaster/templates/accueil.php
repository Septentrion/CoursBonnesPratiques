<?php /* Template accueil — voir index.php pour les variables disponibles */ ?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><title>ShopMaster</title></head>
<body>
<h1>ShopMaster — Bienvenue</h1>
<?php foreach ($prodsParCategorie as $cat => $prods): ?>
<h2><?= htmlspecialchars(ucfirst($cat)) ?></h2>
<?php foreach ($prods as $p): ?>
<div>
    <strong><?= htmlspecialchars($p['nom']) ?></strong>
    — <?= number_format($p['prix'], 2, ',', ' ') ?> €
    — Stock : <?= $p['stock'] ?>
    <a href="?action=produit&id=<?= $p['id'] ?>">Voir</a>
</div>
<?php endforeach; ?>
<?php endforeach; ?>
</body></html>
