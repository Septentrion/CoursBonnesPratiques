<?php /* Dashboard admin — $stats disponible depuis index.php */ ?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Admin — Dashboard</title></head>
<body>
<h1>Tableau de bord</h1>
<p>CA total : <?= number_format($stats['ca_total'], 2, ',', ' ') ?> €</p>
<p>CA mois : <?= number_format($stats['ca_mois'], 2, ',', ' ') ?> €</p>
<p>Commandes : <?= $stats['nb_commandes'] ?></p>
<p>En attente : <?= $stats['en_attente'] ?></p>
<?php if ($stats['top_produit']): ?>
<p>Top produit : <?= htmlspecialchars($stats['top_produit']['nom']) ?>
   (<?= $stats['top_produit']['total_vendu'] ?> ventes)</p>
<?php endif; ?>
<nav>
    <a href="?action=admin-commandes">Commandes</a> |
    <a href="?action=admin-produits">Produits</a> |
    <a href="?action=admin-rapport">Rapport mensuel</a>
</nav>
</body></html>
