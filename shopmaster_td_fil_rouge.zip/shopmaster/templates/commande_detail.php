<?php
// Template détail commande
// ATTENTION : ne pas mettre de logique ici disait Marc, mais on l'a quand même fait
global $db;
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Commande <?= $cmd['ref'] ?></title></head>
<body>
<h1>Commande <?= $cmd['ref'] ?></h1>

<?php
// Requête SQL directement dans la vue — personne n'a osé refactoriser ça
$u = $db->prepare("SELECT nom, prenom, email FROM users WHERE id = ?");
$u->execute([$cmd['user_id']]);
$user = $u->fetch(PDO::FETCH_ASSOC);
?>

<div class="client">
    <h3>Client</h3>
    <p><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></p>
    <p><?= htmlspecialchars($user['email']) ?></p>
</div>

<div class="livraison">
    <h3>Adresse de livraison</h3>
    <p>
        <?= htmlspecialchars($cmd['adresse_livraison']) ?><br>
        <?= htmlspecialchars($cmd['cp_livraison']) ?> <?= htmlspecialchars($cmd['ville_livraison']) ?><br>
        <?= htmlspecialchars($cmd['pays_livraison']) ?>
    </p>
</div>

<div class="statut">
    <h3>Statut</h3>
    <?php
    // Logique d'affichage statut dans la vue
    $statuts = [
        'en_attente' => ['label' => 'En attente de paiement', 'couleur' => 'orange'],
        'validee'    => ['label' => 'Validée',                'couleur' => 'blue'],
        'en_prep'    => ['label' => 'En préparation',         'couleur' => 'purple'],
        'expediee'   => ['label' => 'Expédiée',               'couleur' => 'teal'],
        'livree'     => ['label' => 'Livrée',                 'couleur' => 'green'],
        'annulee'    => ['label' => 'Annulée',                'couleur' => 'red'],
        'remboursee' => ['label' => 'Remboursée',             'couleur' => 'gray'],
    ];
    $s = $statuts[$cmd['statut']] ?? ['label' => $cmd['statut'], 'couleur' => 'black'];
    ?>
    <span style="color: <?= $s['couleur'] ?>; font-weight: bold;">
        <?= $s['label'] ?>
    </span>

    <?php if ($cmd['date_envoi']): ?>
        <p>Expédiée le : <?= date('d/m/Y', strtotime($cmd['date_envoi'])) ?></p>
    <?php endif; ?>
</div>

<div class="lignes">
    <h3>Articles commandés</h3>
    <table border="1" cellpadding="8">
        <thead>
            <tr>
                <th>Produit</th>
                <th>Réf.</th>
                <th>Qté</th>
                <th>Prix unit. TTC</th>
                <th>Total TTC</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sousTotal = 0;
            foreach ($lignes as $l):
                $tot = $l['prix_unitaire'] * $l['quantite'];
                $sousTotal += $tot;
            ?>
            <tr>
                <td><?= htmlspecialchars($l['nom']) ?></td>
                <td><?= htmlspecialchars($l['ref']) ?></td>
                <td><?= $l['quantite'] ?></td>
                <td><?= number_format($l['prix_unitaire'], 2, ',', ' ') ?> €</td>
                <td><?= number_format($tot, 2, ',', ' ') ?> €</td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4">Sous-total articles</td>
                <td><?= number_format($sousTotal, 2, ',', ' ') ?> €</td>
            </tr>
            <?php if ($cmd['remise'] > 0): ?>
            <tr>
                <td colspan="4">
                    Remise
                    <?php if ($cmd['code_promo']): ?>
                        (code : <?= htmlspecialchars($cmd['code_promo']) ?>)
                    <?php endif; ?>
                </td>
                <td>- <?= number_format($cmd['remise'], 2, ',', ' ') ?> €</td>
            </tr>
            <?php endif; ?>
            <?php
            // Calcul des frais de port dans la vue — logique métier
            $fp = $cmd['total'] - ($sousTotal - $cmd['remise']);
            if ($fp < 0) $fp = 0;  // sécurité
            ?>
            <tr>
                <td colspan="4">
                    Frais de port
                    <?php if ($fp == 0): ?><em>(offerts)</em><?php endif; ?>
                </td>
                <td><?= $fp > 0 ? number_format($fp, 2, ',', ' ') . ' €' : 'Gratuit' ?></td>
            </tr>
            <tr style="font-weight: bold;">
                <td colspan="4">Total TTC</td>
                <td><?= number_format($cmd['total'], 2, ',', ' ') ?> €</td>
            </tr>
            <tr>
                <td colspan="4">dont TVA 20%</td>
                <td><?= number_format($cmd['tva_montant'], 2, ',', ' ') ?> €</td>
            </tr>
        </tfoot>
    </table>
</div>

<div class="paiement">
    <h3>Paiement</h3>
    <p>Mode : <?= htmlspecialchars($cmd['mode_paiement']) ?></p>
    <?php if ($cmd['transaction_id']): ?>
        <p>Transaction : <?= htmlspecialchars($cmd['transaction_id']) ?></p>
    <?php endif; ?>
</div>

<?php if ($cmd['notes']): ?>
<div class="notes">
    <h3>Notes</h3>
    <p><?= nl2br(htmlspecialchars($cmd['notes'])) ?></p>
</div>
<?php endif; ?>

<?php
// Logique d'éligibilité au retour dans la vue
$dateCommande = strtotime($cmd['date_commande']);
$joursEcoules = (time() - $dateCommande) / 86400;
$retourPossible = $cmd['statut'] === 'livree' && $joursEcoules <= 14;
?>
<?php if ($retourPossible): ?>
<div style="background:#fff3cd; padding:10px; border:1px solid #ffc107;">
    <strong>Retour possible</strong> : vous avez jusqu'au
    <?= date('d/m/Y', $dateCommande + 14 * 86400) ?> pour retourner votre commande.
</div>
<?php endif; ?>

<p><a href="?action=mon-compte">← Retour à mon compte</a></p>
</body>
</html>
