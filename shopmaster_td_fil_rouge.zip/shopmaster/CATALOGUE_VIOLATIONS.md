# Catalogue des violations — Guide pédagogique

Ce document répertorie toutes les violations intentionnelles présentes dans la
base de code ShopMaster, organisées par principe et par fichier.

---

## Violations du principe SRP

### `src/CommandeManager.php`
- **creerCommande()** cumule : validation, calcul de prix, gestion du stock,
  calcul de remises, persistence, gestion des alertes stock, envoi d'emails
  client et admin, mise à jour des stats utilisateur.
- **getStats()** contient la logique de "meilleur produit" qui appartient
  à un domaine produits, pas commandes.
- **genererFacture()** fait de la mise en forme HTML dans une couche métier.

### `src/UserManager.php`
- **inscrire()** valide, persiste, envoie un email ET initialise la session.
- **connecter()** gère l'authentification ET la session.
- **getProfil()** charge les commandes (logique de CommandeManager).
- **changerMdp()** envoie un email de confirmation directement.
- **demanderReinitialisationMdp()** stocke le token dans le champ `notes`
  (hack jamais corrigé).

### `src/RapportManager.php`
- **genererRapportMensuel()** calcule les métriques, formate en CSV, envoie
  l'email — trois responsabilités distinctes.
- **rapportProduits()** formate en HTML, CSV ou JSON selon le paramètre —
  violation OCP + SRP.

### `scripts/rapport_mensuel.py`
- **faire_rapport()** interroge la BDD, calcule les métriques, génère le CSV,
  écrit sur le disque, et envoie l'email SMTP.
- Affichage et calcul des tendances dans **analyser_tendances()**.

---

## Violations du principe OCP

### `src/ProduitManager.php` — `calculerPrix()`
- Un `if/elseif` cascade sur la catégorie du produit.
- Ajouter une nouvelle catégorie = modifier cette méthode.

### `src/ProduitManager.php` — `CalculateurRemise::appliquer()`
- `switch` sur le type de remise : ajouter un type = modifier la méthode.
- Logique dupliquée depuis la hiérarchie `Remise`.

### `src/RapportManager.php` — `rapportProduits()`
- `if/elseif` sur le format de sortie (html/csv/json).
- Ajouter XML = modifier la méthode.

### `index.php`
- Le `switch($action)` géant : ajouter une route = modifier le fichier.

---

## Violations du principe LSP

### `src/ProduitManager.php` — hiérarchie `Remise`
- **`RemiseSpeciale::calculer()`** : modifie `$_SESSION['panier']` (effet de
  bord caché) en plus de retourner une valeur. Viole la postcondition implicite
  "retourne uniquement le montant de la remise".
- **`Remise::calculer()`** (classe de base) : retourne toujours 0, rendant
  le polymorphisme inutile et trompeur.
- **`RemiseFixe::calculer()`** : peut retourner une valeur différente de
  `$this->valeur` (si total < valeur fixe), ce qui surprend l'appelant.

---

## Violations du principe ISP

### `src/ProduitManager.php` — classe `Remise`
- `estActive()` est une méthode de `RemiseSaisonniere` qui n'a rien à faire
  dans une interface commune de remise.
- `$zoneGeo` est un attribut "prévu pour plus tard" qui n'est jamais utilisé.

### `tests/tests.php`
- Tests couplés à la structure interne des classes (passent des tableaux
  `['prix' => ..., 'categorie' => ...]` directement à `calculerPrix()`).

---

## Violations du principe DIP

### `src/CommandeManager.php`
- `global $db` dans le constructeur : dépendance directe à une variable globale.
- `mail()` appelé directement : impossible de tester sans serveur SMTP.
- Instanciations directes (`new PDOStatement` via `$this->db->prepare()`
  sans injection).

### `src/UserManager.php`
- Même problème `global $db`.
- `session_start()` dans le constructeur : effet de bord au chargement.

### `index.php`
- `new CommandeManager()`, `new UserManager()`, `new ProduitManager()` :
  aucune injection de dépendances — Composition Root inexistant.

### `scripts/rapport_mensuel.py`
- `conn` globale partagée entre toutes les fonctions.
- Credentials SMTP codés en dur.
- Connexion SMTP créée dans `faire_rapport()`.

---

## Code smells

### Feature Envy
- `CommandeManager::getStats()` accède aux données produits.
- `UserManager::getProfil()` charge les commandes.
- `RapportManager` accède aux données commandes, produits ET utilisateurs.
- `templates/commande_detail.php` fait une requête SQL pour charger l'utilisateur.

### Shotgun Surgery
- Le taux de TVA (20%) est codifié en dur dans : `config/db.php` (constant),
  `src/CommandeManager.php`, `src/helpers.php` (htToTtc/ttcToHt),
  `templates/commande_detail.php`.
- Les frais de port (4,90 / 9,90 / seuil 50€) sont dans : `config/db.php`
  (constants), `src/helpers.php` (fraisPort()), `src/CommandeManager.php`
  (creerCommande()), `index.php` (calcul panier).

### Divergent Change
- `RapportManager` change si : les métriques changent, le format CSV change,
  les destinataires changent, la source de données change.
- `CommandeManager::creerCommande()` change si : la politique de remise change,
  le prestataire SMTP change, le schéma BDD change, les règles de stock changent.

### Primitive Obsession
- Les adresses sont des tableaux associatifs `['adresse', 'ville', 'cp', 'pays']`
  sans type dédié.
- Les montants sont des `float` sans devise associée.
- Les dates sont des chaînes `string` sans validation ni type.
- Le statut d'une commande est une `string` libre sans enum.
- Les identifiants (`user_id`, `produit_id`) sont des `int` sans distinction.

### Nommage opaque
- `$f` dans `scripts/rapport_mensuel.py` (handle de fichier).
- `$r1`, `$nc`, `$tops` dans `rapport_mensuel.py`.
- `$u`, `$c`, `$p` utilisés comme abréviations partout dans les managers.
- La méthode `f()` dans `helpers.php` (formatage monétaire).
- `$ok`, `$ko` dans les tests.

### Magic numbers
- `0.20` (taux TVA) partout.
- `4.90`, `9.90` (frais de port) en plusieurs endroits.
- `50.0` (seuil de gratuité) dupliqué.
- `14` (jours de retour) dans `templates/commande_detail.php`.
- `86400` (secondes dans un jour) dans le même template.
- `6` (longueur minimale du mot de passe) dans `UserManager`.

### Commentaires problématiques
- `// TODO: mettre en variable d'environnement` jamais réalisé (db.php).
- `// TODO: centraliser ça quelque part` (helpers.php ligne 34).
- `// solution temporaire jamais corrigée` (UserManager::demanderReinitialisation).
- `// Ne pas toucher à CommandeManager sans demander à Marc` (README).
- Commentaires qui expliquent *quoi* (`// Calculer le total`) et non *pourquoi*.

### Gestion d'erreurs silencieuse
- `try { ... smtp ... } except Exception as e: print(f"Erreur email : {e}")` —
  l'erreur est affichée mais le script continue.
- `if ($prod['stock'] <= $d['prod']['stock_min'])` alerte stock sans loguer
  si le `mail()` échoue.
- `logErreur()` dans `UserManager::connecter()` mais nulle part ailleurs.

---

## Dans les tests

- Pas d'isolation : les tests modifient la vraie base de données.
- Pas de setup/teardown fiable (le nettoyage est manuel et oublié si un test plante).
- Pas de test des cas limites pour les remises (RemiseSpeciale avec effet de bord).
- Tests qui documentent des bugs (`// BUG connu` dans les tests de prix PRO).
- Couplage fort à l'implémentation interne (tableaux bruts passés aux méthodes).
- Framework artisanal (`assert_eq`, `assert_true`) plutôt que PHPUnit.

---

## Sessions de refactoring suggérées

### Session 1 — Jour 1 matin (Clean Code, smells)
- Renommer tous les noms opaques (`$f`, `$r1`, `$u`, `$p`…)
- Extraire les magic numbers en constantes nommées
- Séparer les commentaires parasites du code auto-documenté
- Identifier et lister tous les smells : Feature Envy, Shotgun Surgery, etc.

### Session 2 — Après le cours SOLID
- Appliquer SRP à `CommandeManager` : extraire `OrderRepository`,
  `StockAlertService`, `OrderConfirmationMailer`, `InvoiceGenerator`
- Appliquer DIP : injecter `PDO` et le mailer via le constructeur
- Appliquer OCP à `calculerPrix()` : pattern Strategy pour les remises
- Corriger la hiérarchie `Remise` (LSP)

### Session 3 — Après le cours DDD
- Introduire les Value Objects : `Money`, `Address`, `OrderId`, `Email`
- Modéliser l'Aggregate `Order` avec ses invariants
- Extraire `OrderRepository` (interface + implémentation)
- Définir un Bounded Context Commandes vs Inventaire

### Session 4 — Après le cours TDD & FP
- Réécrire les tests avec PHPUnit et des Fakes
- Isoler les fonctions pures de calcul (remises, frais de port)
- Appliquer Railway-Oriented Programming à la validation de commande
- Ajouter des property-based tests sur `Money` et les règles de remise
