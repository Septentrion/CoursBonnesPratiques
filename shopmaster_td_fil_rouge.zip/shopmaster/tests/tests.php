<?php

/**
 * Tests maison — pas de framework, pas d'isolation, couplage fort à la BDD.
 * Lancez avec : php tests/tests.php
 *
 * ATTENTION : ces tests modifient la base de données !
 * Toujours tester sur une copie.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/CommandeManager.php';
require_once __DIR__ . '/../src/UserManager.php';
require_once __DIR__ . '/../src/ProduitManager.php';

$ok  = 0;
$ko  = 0;
$errs = [];

function assert_eq($desc, $attendu, $obtenu) {
    global $ok, $ko, $errs;
    if ($attendu == $obtenu) {
        echo "  ✓ $desc\n";
        $ok++;
    } else {
        echo "  ✗ $desc\n";
        echo "    Attendu : " . var_export($attendu, true) . "\n";
        echo "    Obtenu  : " . var_export($obtenu, true) . "\n";
        $ko++;
        $errs[] = $desc;
    }
}

function assert_true($desc, $val) {
    assert_eq($desc, true, (bool)$val);
}

function assert_false($desc, $val) {
    assert_eq($desc, false, (bool)$val);
}


echo "=== Tests ShopMaster ===\n\n";

// ── Tests helpers ─────────────────────────────────────────────────────────────

echo "-- helpers.php --\n";
assert_eq('f(10) formate avec 2 décimales', '10,00 €', f(10));
assert_eq('f(0) retourne zéro formaté', '0,00 €', f(0));
assert_eq('nettoyer supprime les balises HTML', 'test', nettoyer('<b>test</b>'));
assert_eq('nettoyer trim les espaces', 'test', nettoyer('  test  '));
assert_eq('fraisPort < 50 retourne 4.90', 4.90, fraisPort(30));
assert_eq('fraisPort >= 50 retourne 0', 0, fraisPort(50));
assert_eq('fraisPort express retourne 9.90', 9.90, fraisPort(30, 'express'));
// Test qui passe pour la mauvaise raison : fraisPort(50) == 0 car >= 50
assert_eq('fraisPort exactement 50 retourne 0', 0, fraisPort(50.00));
echo "\n";

// ── Tests ProduitManager ──────────────────────────────────────────────────────

echo "-- ProduitManager (calcul prix) --\n";
$pm = new ProduitManager();

// Tests avec des produits fictifs — couplage à la structure interne
$prodElec = ['prix' => 100.0, 'categorie' => 'electronique'];
$prodVet  = ['prix' => 50.0,  'categorie' => 'vetements'];
$prodAlim = ['prix' => 10.0,  'categorie' => 'alimentaire'];

assert_eq('Prix électronique qte=1 sans remise', 100.0, $pm->calculerPrix($prodElec, 1));
assert_eq('Prix électronique qte=5, remise 8%', 92.0, $pm->calculerPrix($prodElec, 5));
assert_eq('Prix électronique qte=10, remise 15%', 85.0, $pm->calculerPrix($prodElec, 10));
assert_eq('Prix vêtements qte=10, remise 12%', 44.0, $pm->calculerPrix($prodVet, 10));
assert_eq('Prix alimentaire qte=50, remise 25%', 7.5, $pm->calculerPrix($prodAlim, 50));

// Test VIP
assert_eq('Prix VIP = 90% du prix normal', 90.0, $pm->calculerPrix($prodElec, 1, 'vip'));
// Test PRO — prix HT
// BUG connu : le prix pro devrait être 100 * 0.85 / 1.20 = 70.83
// mais le résultat dépend de l'ordre des opérations
$prixPro = $pm->calculerPrix($prodElec, 1, 'pro');
assert_true('Prix PRO est inférieur au prix normal', $prixPro < 100);

echo "\n";

// ── Tests Remise ──────────────────────────────────────────────────────────────

echo "-- Remise --\n";
require_once __DIR__ . '/../src/ProduitManager.php';

$rPct  = new RemisePourcentage(10);
$rFixe = new RemiseFixe(15);

assert_eq('RemisePourcentage 10% sur 100', 10.0, $rPct->calculer(100));
assert_eq('RemisePourcentage 10% sur 50',   5.0, $rPct->calculer(50));
assert_eq('RemiseFixe 15€ sur 100',          15,  $rFixe->calculer(100));
// Ce test documente un comportement : si le total < remise fixe
assert_eq('RemiseFixe 15€ sur 10 = 10 (pas négatif)', 10, $rFixe->calculer(10));

// Test CalculateurRemise (statique)
assert_eq('Calculateur pourcent', 10.0, CalculateurRemise::appliquer('pourcent', 10, 100));
assert_eq('Calculateur fixe',     15.0, CalculateurRemise::appliquer('fixe', 15, 100));
assert_eq('Calculateur type inconnu retourne 0', 0, CalculateurRemise::appliquer('xyz', 10, 100));

echo "\n";

// ── Tests CommandeManager — couplage fort à la BDD réelle ─────────────────────

echo "-- CommandeManager (nécessite une BDD initialisée) --\n";

global $db;

// Insérer un utilisateur de test — modifie la vraie BDD !
$db->exec("DELETE FROM users WHERE email = 'test@shopmaster-test.fr'");
$db->prepare(
    "INSERT INTO users (nom, prenom, email, mdp, actif, date_inscription)
     VALUES ('Test', 'Utilisateur', 'test@shopmaster-test.fr', 'hash', 1, datetime('now'))"
)->execute();
$uid = $db->lastInsertId();

// Insérer un produit de test
$db->exec("DELETE FROM produits WHERE ref = 'TEST-001'");
$db->prepare(
    "INSERT INTO produits (ref, nom, prix, stock, stock_min, actif, tva, categorie)
     VALUES ('TEST-001', 'Produit de test', 29.99, 100, 5, 1, 20, 'test')"
)->execute();
$pid = $db->lastInsertId();

$cm = new CommandeManager();

// Test panier vide
$res = $cm->creerCommande($uid, [], ['adresse' => '1 rue test', 'ville' => 'Paris', 'cp' => '75001'], 'carte');
assert_false('Panier vide retourne ok=false', $res['ok']);

// Test utilisateur inexistant
$res = $cm->creerCommande(99999, [$pid => 1], ['adresse' => '1 rue test', 'ville' => 'Paris', 'cp' => '75001'], 'carte');
assert_false('User inexistant retourne ok=false', $res['ok']);

// Test commande valide — envoi email peut échouer silencieusement
$panier = [$pid => 2];
$adresse = ['adresse' => '1 rue du Test', 'ville' => 'Paris', 'cp' => '75001', 'mode_livraison' => 'standard'];
$res = $cm->creerCommande($uid, $panier, $adresse, 'carte');
assert_true('Commande valide retourne ok=true', $res['ok']);

if ($res['ok']) {
    $cmd = $cm->getCommande($res['commande_id']);
    assert_eq('Statut initial = en_attente', 'en_attente', $cmd['statut']);

    // Total attendu : 2 * 29.99 = 59.98 >= 50€ donc frais port offerts
    // Mais le calcul est dans creerCommande donc on teste le résultat final
    assert_true('Total > 0', $res['total'] > 0);
    assert_eq('Référence commence par CMD-', 'CMD-', substr($res['ref'], 0, 4));

    // Tester changement de statut
    $ok = $cm->changerStatut($res['commande_id'], 'validee', false);
    assert_true('Changement statut validee réussit', $ok);

    $cmd2 = $cm->getCommande($res['commande_id']);
    assert_eq('Statut mis à jour = validee', 'validee', $cmd2['statut']);

    // Test transition invalide
    $db->prepare("UPDATE commandes SET statut = 'annulee' WHERE id = ?")->execute([$res['commande_id']]);
    $ok2 = $cm->changerStatut($res['commande_id'], 'validee', false);
    assert_false('Impossible de valider une commande annulée', $ok2);
}

// Nettoyage — si on oublie, les tests suivants peuvent planter
$db->prepare("DELETE FROM commande_lignes WHERE commande_id IN (SELECT id FROM commandes WHERE user_id = ?)")->execute([$uid]);
$db->prepare("DELETE FROM commandes WHERE user_id = ?")->execute([$uid]);
$db->prepare("DELETE FROM users WHERE id = ?")->execute([$uid]);
$db->prepare("DELETE FROM produits WHERE id = ?")->execute([$pid]);

echo "\n";

// ── Bilan ─────────────────────────────────────────────────────────────────────

echo "=== Résultat : $ok/" . ($ok + $ko) . " tests passés ===\n";
if ($ko > 0) {
    echo "\nEchecs :\n";
    foreach ($errs as $e) echo "  - $e\n";
    exit(1);
}
echo "Tous les tests sont verts !\n";
