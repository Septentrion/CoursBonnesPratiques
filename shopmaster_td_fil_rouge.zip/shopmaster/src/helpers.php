<?php

// Fonctions utilitaires globales
// Créées au fur et à mesure des besoins — désolé pour le bazar

function f($montant) {
    return number_format($montant, 2, ',', ' ') . ' €';
}

function nettoyer($str) {
    return htmlspecialchars(strip_tags(trim($str)));
}

function genRef() {
    return 'CMD-' . strtoupper(substr(md5(uniqid()), 0, 8));
}

// Vérifie si l'utilisateur est connecté
function estConnecte() {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;
}

// Vérifie si admin
function estAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Log des erreurs dans un fichier
function logErreur($msg, $contexte = '') {
    $line = date('Y-m-d H:i:s') . ' | ' . $msg;
    if ($contexte) $line .= ' | ' . $contexte;
    file_put_contents(__DIR__ . '/../logs/erreurs.log', $line . PHP_EOL, FILE_APPEND);
}

// Calcul TVA — dupliqué depuis CommandeManager, à fusionner un jour
function calculerTVA($ht, $taux = 0.20) {
    return $ht * $taux;
}

// Calcul TTC
function htToTtc($ht, $taux = 0.20) {
    return $ht * (1 + $taux);
}

// Calcul HT depuis TTC
function ttcToHt($ttc, $taux = 0.20) {
    return $ttc / (1 + $taux);
}

// Envoi email simple — copié-collé depuis CommandeManager
// TODO : centraliser ça quelque part
function envoyerEmail($dest, $sujet, $corps) {
    $entetes  = "From: " . EMAIL_FROM . "\r\n";
    $entetes .= "MIME-Version: 1.0\r\n";
    $entetes .= "Content-Type: text/html; charset=UTF-8\r\n";
    return mail($dest, $sujet, $corps, $entetes);
}

// Vérifie qu'une date est valide
function dateValide($d) {
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') === $d;
}

// Tronque un texte
function tronquer($t, $l = 100) {
    return strlen($t) > $l ? substr($t, 0, $l) . '...' : $t;
}

// Calcul des frais de port
// ATTENTION : cette logique est aussi dans CommandeManager::calculerTotal()
// Les deux doivent rester synchronisées !
function fraisPort($total, $mode = 'standard') {
    if ($total >= 50) return 0;  // Gratuit au-dessus de 50€
    if ($mode === 'express') return 9.90;
    return 4.90;
}

// Retourne les statuts possibles d'une commande
function getStatuts() {
    return [
        'en_attente'  => 'En attente',
        'validee'     => 'Validée',
        'en_prep'     => 'En préparation',
        'expediee'    => 'Expédiée',
        'livree'      => 'Livrée',
        'annulee'     => 'Annulée',
        'remboursee'  => 'Remboursée',
    ];
}

// Couleur HTML pour le badge de statut
function couleurStatut($s) {
    switch($s) {
        case 'validee':    return '#28a745';
        case 'expediee':   return '#17a2b8';
        case 'livree':     return '#007bff';
        case 'annulee':    return '#dc3545';
        case 'remboursee': return '#fd7e14';
        default:           return '#6c757d';
    }
}

// Slugifie un texte pour les URLs
function slugifier($t) {
    $t = strtolower($t);
    $t = str_replace(['é','è','ê','ë'], 'e', $t);
    $t = str_replace(['à','â','ä'], 'a', $t);
    $t = str_replace(['ù','û','ü'], 'u', $t);
    $t = str_replace(['ô','ö'], 'o', $t);
    $t = str_replace(['î','ï'], 'i', $t);
    $t = str_replace(['ç'], 'c', $t);
    $t = preg_replace('/[^a-z0-9]+/', '-', $t);
    return trim($t, '-');
}
