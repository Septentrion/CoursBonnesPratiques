<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

/**
 * Génération des rapports.
 * Change quand : le format change, les métriques changent,
 * la source de données change, le destinataire change.
 * = Divergent Change
 */
class RapportManager
{
    private $db;

    public function __construct() {
        global $db;
        $this->db = $db;
    }

    // Rapport mensuel — fait tout : calcule, formate, envoie
    // Raisons de changer : métriques métier, format CSV, destinataires email
    public function genererRapportMensuel($annee, $mois) {
        $debut = sprintf('%04d-%02d-01', $annee, $mois);
        $fin   = date('Y-m-t', strtotime($debut));

        // 1. Chiffre d'affaires
        $ca = $this->db->prepare(
            "SELECT COALESCE(SUM(total), 0) as ca,
                    COALESCE(SUM(total_ht), 0) as ca_ht,
                    COUNT(*) as nb_commandes
             FROM commandes
             WHERE date(date_commande) BETWEEN ? AND ?
             AND statut NOT IN ('annulee')"
        );
        $ca->execute([$debut, $fin]);
        $caData = $ca->fetch(PDO::FETCH_ASSOC);

        // 2. Remises accordées — logique commandes dans RapportManager (Feature Envy)
        $remises = $this->db->prepare(
            "SELECT COALESCE(SUM(remise), 0) as total_remises,
                    COUNT(CASE WHEN remise > 0 THEN 1 END) as nb_avec_remise
             FROM commandes
             WHERE date(date_commande) BETWEEN ? AND ?"
        );
        $remises->execute([$debut, $fin]);
        $remisesData = $remises->fetch(PDO::FETCH_ASSOC);

        // 3. Top produits — logique produit dans RapportManager
        $tops = $this->db->prepare(
            "SELECT p.ref, p.nom, p.categorie,
                    SUM(cl.quantite) as qte_vendue,
                    SUM(cl.quantite * cl.prix_unitaire) as ca_produit,
                    COUNT(DISTINCT cl.commande_id) as nb_commandes
             FROM commande_lignes cl
             JOIN produits p ON p.id = cl.produit_id
             JOIN commandes c ON c.id = cl.commande_id
             WHERE date(c.date_commande) BETWEEN ? AND ?
             AND c.statut NOT IN ('annulee')
             GROUP BY p.id
             ORDER BY ca_produit DESC
             LIMIT 10"
        );
        $tops->execute([$debut, $fin]);
        $topProduits = $tops->fetchAll(PDO::FETCH_ASSOC);

        // 4. Nouveaux clients — logique user dans RapportManager
        $nc = $this->db->prepare(
            "SELECT COUNT(*) as nouveaux
             FROM users WHERE date(date_inscription) BETWEEN ? AND ?"
        );
        $nc->execute([$debut, $fin]);
        $ncData = $nc->fetch(PDO::FETCH_ASSOC);

        // 5. Panier moyen
        $pm = $caData['nb_commandes'] > 0
            ? $caData['ca'] / $caData['nb_commandes']
            : 0;

        // 6. Commandes par statut
        $statuts = $this->db->prepare(
            "SELECT statut, COUNT(*) as nb, COALESCE(SUM(total), 0) as total
             FROM commandes
             WHERE date(date_commande) BETWEEN ? AND ?
             GROUP BY statut"
        );
        $statuts->execute([$debut, $fin]);
        $statutsData = $statuts->fetchAll(PDO::FETCH_ASSOC);

        // 7. Générer le CSV — mise en forme dans la même méthode
        $csv  = "Rapport mensuel ShopMaster — " . sprintf('%02d/%04d', $mois, $annee) . "\n\n";
        $csv .= "CHIFFRE D'AFFAIRES\n";
        $csv .= "CA TTC;" . number_format($caData['ca'], 2, ',', ' ') . " €\n";
        $csv .= "CA HT;" . number_format($caData['ca_ht'], 2, ',', ' ') . " €\n";
        $csv .= "Nb commandes;" . $caData['nb_commandes'] . "\n";
        $csv .= "Panier moyen;" . number_format($pm, 2, ',', ' ') . " €\n";
        $csv .= "Total remises;" . number_format($remisesData['total_remises'], 2, ',', ' ') . " €\n";
        $csv .= "Commandes avec remise;" . $remisesData['nb_avec_remise'] . "\n";
        $csv .= "Nouveaux clients;" . $ncData['nouveaux'] . "\n\n";

        $csv .= "STATUTS\n";
        $csv .= "Statut;Nb;CA\n";
        foreach ($statutsData as $s) {
            $csv .= $s['statut'] . ";" . $s['nb'] . ";" . number_format($s['total'], 2, ',', ' ') . " €\n";
        }

        $csv .= "\nTOP 10 PRODUITS\n";
        $csv .= "Ref;Nom;Catégorie;Qté vendue;CA;Nb commandes\n";
        foreach ($topProduits as $p) {
            $csv .= $p['ref'] . ";" . $p['nom'] . ";" . $p['categorie'] . ";"
                  . $p['qte_vendue'] . ";"
                  . number_format($p['ca_produit'], 2, ',', ' ') . " €;"
                  . $p['nb_commandes'] . "\n";
        }

        // 8. Envoyer par email — directement ici
        $filename = 'rapport_' . $annee . '_' . sprintf('%02d', $mois) . '.csv';
        $boundary = md5(uniqid());
        $headers  = "From: " . EMAIL_FROM . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

        $body  = "--$boundary\r\n";
        $body .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
        $body .= "Veuillez trouver ci-joint le rapport du mois de "
               . sprintf('%02d/%04d', $mois, $annee) . ".\r\n\r\n";
        $body .= "--$boundary\r\n";
        $body .= "Content-Type: text/csv; name=\"$filename\"\r\n";
        $body .= "Content-Disposition: attachment; filename=\"$filename\"\r\n\r\n";
        $body .= $csv . "\r\n";
        $body .= "--$boundary--";

        mail('direction@shopmaster.fr', "Rapport mensuel " . sprintf('%02d/%04d', $mois, $annee),
             $body, $headers);

        return [
            'ca'           => $caData,
            'remises'      => $remisesData,
            'top_produits' => $topProduits,
            'nouveaux_clients' => $ncData['nouveaux'],
            'panier_moyen' => $pm,
            'statuts'      => $statutsData,
            'csv'          => $csv,
        ];
    }

    // Rapport produits — Divergent Change : change si le format change OU si les métriques changent
    public function rapportProduits($format = 'html') {
        $data = $this->db->query(
            "SELECT p.*,
                    COALESCE(SUM(cl.quantite), 0) as total_vendu,
                    COALESCE(SUM(cl.quantite * cl.prix_unitaire), 0) as ca_genere
             FROM produits p
             LEFT JOIN commande_lignes cl ON cl.produit_id = p.id
             LEFT JOIN commandes c ON c.id = cl.commande_id AND c.statut != 'annulee'
             GROUP BY p.id
             ORDER BY ca_genere DESC"
        )->fetchAll(PDO::FETCH_ASSOC);

        // Format dans la même méthode — OCP violation
        if ($format === 'csv') {
            $out = "Ref;Nom;Prix;Stock;CA généré;Qté vendue\n";
            foreach ($data as $p) {
                $out .= $p['ref'] . ";" . $p['nom'] . ";"
                      . $p['prix'] . ";" . $p['stock'] . ";"
                      . number_format($p['ca_genere'], 2, ',', ' ') . ";"
                      . $p['total_vendu'] . "\n";
            }
            return $out;
        } elseif ($format === 'json') {
            return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        } else {
            // HTML — mélange données et présentation
            $html = '<table class="table"><thead><tr>'
                  . '<th>Ref</th><th>Nom</th><th>Prix</th><th>Stock</th>'
                  . '<th>CA généré</th><th>Qté vendue</th></tr></thead><tbody>';
            foreach ($data as $p) {
                $class = $p['stock'] <= $p['stock_min'] ? ' class="table-danger"' : '';
                $html .= "<tr$class><td>{$p['ref']}</td><td>{$p['nom']}</td>"
                       . "<td>" . number_format($p['prix'], 2, ',', ' ') . " €</td>"
                       . "<td>{$p['stock']}</td>"
                       . "<td>" . number_format($p['ca_genere'], 2, ',', ' ') . " €</td>"
                       . "<td>{$p['total_vendu']}</td></tr>";
            }
            return $html . '</tbody></table>';
        }
    }

    // Rapport clients — encore une responsabilité dans RapportManager
    public function rapportClients() {
        return $this->db->query(
            "SELECT u.id, u.nom, u.prenom, u.email, u.date_inscription,
                    COUNT(c.id) as nb_commandes,
                    COALESCE(SUM(c.total), 0) as total_depense,
                    MAX(c.date_commande) as derniere_commande
             FROM users u
             LEFT JOIN commandes c ON c.user_id = u.id AND c.statut != 'annulee'
             GROUP BY u.id
             ORDER BY total_depense DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }
}
