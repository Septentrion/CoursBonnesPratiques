<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

/**
 * Gestion des commandes.
 * Cette classe fait tout ce qui touche aux commandes.
 * Contacter Marc avant de modifier.
 */
class CommandeManager
{
    private $db;

    public function __construct() {
        global $db;
        $this->db = $db;
    }

    // Crée une nouvelle commande depuis le panier en session
    public function creerCommande($userId, $panier, $adresse, $modePaiement, $codePromo = '') {
        // Récupérer l'utilisateur
        $u = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $u->execute([$userId]);
        $user = $u->fetch(PDO::FETCH_ASSOC);

        if (!$user || !$user['actif']) {
            return ['ok' => false, 'msg' => 'Utilisateur invalide'];
        }

        // Calculer le total
        $total   = 0;
        $details = [];
        foreach ($panier as $pid => $qte) {
            $p = $this->db->prepare("SELECT * FROM produits WHERE id = ? AND actif = 1");
            $p->execute([$pid]);
            $prod = $p->fetch(PDO::FETCH_ASSOC);

            if (!$prod) continue;

            if ($prod['stock'] < $qte) {
                return ['ok' => false, 'msg' => 'Stock insuffisant pour ' . $prod['nom']];
            }

            $total += $prod['prix'] * $qte;
            $details[] = ['prod' => $prod, 'qte' => $qte, 'pu' => $prod['prix']];
        }

        if ($total <= 0) {
            return ['ok' => false, 'msg' => 'Panier vide'];
        }

        // Appliquer le code promo
        $remise = 0;
        $cp     = null;
        if ($codePromo) {
            $stmt = $this->db->prepare(
                "SELECT * FROM codes_promo WHERE code = ? AND actif = 1
                 AND (date_fin IS NULL OR date_fin >= date('now'))
                 AND nb_utilisations < max_utilisations"
            );
            $stmt->execute([$codePromo]);
            $cp = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($cp) {
                if ($total < $cp['min_commande']) {
                    return ['ok' => false, 'msg' => 'Montant minimum non atteint pour ce code'];
                }
                if ($cp['type'] === 'pourcent') {
                    $remise = $total * ($cp['valeur'] / 100);
                } elseif ($cp['type'] === 'fixe') {
                    $remise = min($cp['valeur'], $total);
                } elseif ($cp['type'] === 'livraison') {
                    // remise sur livraison — géré plus bas
                    $remise = 0;
                }
            } else {
                return ['ok' => false, 'msg' => 'Code promo invalide ou expiré'];
            }
        }

        $totalApresRemise = $total - $remise;

        // Frais de port
        $fp = 4.90;
        if ($totalApresRemise >= 50) {
            $fp = 0;
        } elseif ($adresse['mode_livraison'] === 'express') {
            $fp = 9.90;
        }
        if ($cp && $cp['type'] === 'livraison') {
            $fp = 0;
        }

        $totalFinal = $totalApresRemise + $fp;
        $ht         = $totalFinal / 1.20;
        $tva        = $totalFinal - $ht;
        $ref        = genRef();

        // Insérer la commande
        $ins = $this->db->prepare(
            "INSERT INTO commandes
             (user_id, ref, statut, total, total_ht, tva_montant, remise, code_promo,
              adresse_livraison, ville_livraison, cp_livraison, pays_livraison,
              mode_paiement, date_commande)
             VALUES (?, ?, 'en_attente', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))"
        );
        $ins->execute([
            $userId, $ref, $totalFinal, round($ht, 2), round($tva, 2),
            round($remise, 2), $codePromo,
            $adresse['adresse'], $adresse['ville'], $adresse['cp'], $adresse['pays'] ?? 'FR',
            $modePaiement,
        ]);
        $cmdId = $this->db->lastInsertId();

        // Insérer les lignes et décrémenter le stock
        foreach ($details as $d) {
            $this->db->prepare(
                "INSERT INTO commande_lignes (commande_id, produit_id, quantite, prix_unitaire)
                 VALUES (?, ?, ?, ?)"
            )->execute([$cmdId, $d['prod']['id'], $d['qte'], $d['pu']]);

            $this->db->prepare(
                "UPDATE produits SET stock = stock - ? WHERE id = ?"
            )->execute([$d['qte'], $d['prod']['id']]);

            // Alerte stock bas
            $stockRestant = $d['prod']['stock'] - $d['qte'];
            if ($stockRestant <= $d['prod']['stock_min']) {
                // Envoyer un email d'alerte stock
                $sujet = '[ShopMaster] Stock bas : ' . $d['prod']['nom'];
                $corps = '<p>Le produit <strong>' . $d['prod']['nom'] . '</strong>'
                       . ' n\'a plus que <strong>' . $stockRestant . '</strong> unités en stock.</p>';
                mail('stock@shopmaster.fr', $sujet, $corps,
                     'From: ' . EMAIL_FROM . "\r\nContent-Type: text/html; charset=UTF-8");
            }
        }

        // Mettre à jour le code promo
        if ($cp) {
            $this->db->prepare(
                "UPDATE codes_promo SET nb_utilisations = nb_utilisations + 1 WHERE id = ?"
            )->execute([$cp['id']]);
        }

        // Mettre à jour les stats utilisateur
        $this->db->prepare(
            "UPDATE users SET nb_commandes = nb_commandes + 1,
             total_achats = total_achats + ?
             WHERE id = ?"
        )->execute([$totalFinal, $userId]);

        // Envoyer l'email de confirmation au client
        $lignesHtml = '';
        foreach ($details as $d) {
            $lignesHtml .= '<tr>'
                . '<td>' . htmlspecialchars($d['prod']['nom']) . '</td>'
                . '<td>' . $d['qte'] . '</td>'
                . '<td>' . number_format($d['pu'], 2, ',', ' ') . ' €</td>'
                . '<td>' . number_format($d['pu'] * $d['qte'], 2, ',', ' ') . ' €</td>'
                . '</tr>';
        }

        $emailCorps = '
        <html><body>
        <h2>Merci pour votre commande !</h2>
        <p>Bonjour ' . htmlspecialchars($user['prenom']) . ',</p>
        <p>Votre commande <strong>' . $ref . '</strong> a bien été enregistrée.</p>
        <table border="1" cellpadding="5">
        <tr><th>Produit</th><th>Qté</th><th>Prix unit.</th><th>Total</th></tr>
        ' . $lignesHtml . '
        </table>
        <p>Remise : ' . number_format($remise, 2, ',', ' ') . ' €</p>
        <p>Frais de port : ' . number_format($fp, 2, ',', ' ') . ' €</p>
        <p><strong>Total TTC : ' . number_format($totalFinal, 2, ',', ' ') . ' €</strong></p>
        </body></html>';

        mail($user['email'], 'Confirmation commande ' . $ref, $emailCorps,
             'From: ' . EMAIL_FROM . "\r\nContent-Type: text/html; charset=UTF-8");

        // Notifier l'admin
        mail('admin@shopmaster.fr',
             '[Admin] Nouvelle commande ' . $ref . ' - ' . number_format($totalFinal, 2) . '€',
             'Nouvelle commande de ' . $user['prenom'] . ' ' . $user['nom'],
             'From: ' . EMAIL_FROM);

        return ['ok' => true, 'commande_id' => $cmdId, 'ref' => $ref, 'total' => $totalFinal];
    }

    // Changer le statut d'une commande
    public function changerStatut($cmdId, $nouveauStatut, $notifier = true) {
        $statuts = ['en_attente','validee','en_prep','expediee','livree','annulee','remboursee'];
        if (!in_array($nouveauStatut, $statuts)) return false;

        $cmd = $this->getCommande($cmdId);
        if (!$cmd) return false;

        // Logique de transition
        if ($cmd['statut'] === 'annulee') return false;
        if ($cmd['statut'] === 'livree' && $nouveauStatut !== 'remboursee') return false;

        // Si on annule, remettre le stock
        if ($nouveauStatut === 'annulee' && $cmd['statut'] !== 'expediee') {
            $lignes = $this->db->prepare(
                "SELECT * FROM commande_lignes WHERE commande_id = ?"
            );
            $lignes->execute([$cmdId]);
            foreach ($lignes->fetchAll(PDO::FETCH_ASSOC) as $l) {
                $this->db->prepare(
                    "UPDATE produits SET stock = stock + ? WHERE id = ?"
                )->execute([$l['quantite'], $l['produit_id']]);
            }
        }

        $extra = [];
        if ($nouveauStatut === 'expediee') {
            $extra = [', date_envoi = datetime(\'now\')'];
        }

        $this->db->prepare(
            "UPDATE commandes SET statut = ? " . implode('', $extra) . " WHERE id = ?"
        )->execute([$nouveauStatut, $cmdId]);

        if ($notifier) {
            $u = $this->db->prepare("SELECT * FROM users WHERE id = ?");
            $u->execute([$cmd['user_id']]);
            $user = $u->fetch(PDO::FETCH_ASSOC);

            $msgs = [
                'validee'    => 'Votre commande ' . $cmd['ref'] . ' a été validée.',
                'en_prep'    => 'Votre commande ' . $cmd['ref'] . ' est en cours de préparation.',
                'expediee'   => 'Votre commande ' . $cmd['ref'] . ' a été expédiée !',
                'annulee'    => 'Votre commande ' . $cmd['ref'] . ' a été annulée.',
                'remboursee' => 'Votre commande ' . $cmd['ref'] . ' a été remboursée.',
            ];

            if (isset($msgs[$nouveauStatut])) {
                mail($user['email'],
                     '[ShopMaster] Mise à jour commande ' . $cmd['ref'],
                     '<html><body><p>' . $msgs[$nouveauStatut] . '</p></body></html>',
                     'From: ' . EMAIL_FROM . "\r\nContent-Type: text/html; charset=UTF-8");
            }
        }
        return true;
    }

    public function getCommande($id) {
        $s = $this->db->prepare("SELECT * FROM commandes WHERE id = ?");
        $s->execute([$id]);
        return $s->fetch(PDO::FETCH_ASSOC);
    }

    public function getCommandesUser($uid) {
        $s = $this->db->prepare(
            "SELECT * FROM commandes WHERE user_id = ? ORDER BY date_commande DESC"
        );
        $s->execute([$uid]);
        return $s->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getLignes($cmdId) {
        $s = $this->db->prepare(
            "SELECT cl.*, p.nom, p.ref, p.image
             FROM commande_lignes cl
             JOIN produits p ON p.id = cl.produit_id
             WHERE cl.commande_id = ?"
        );
        $s->execute([$cmdId]);
        return $s->fetchAll(PDO::FETCH_ASSOC);
    }

    // Stats pour le dashboard admin — ici parce que pas de meilleur endroit
    public function getStats() {
        $ca  = $this->db->query(
            "SELECT COALESCE(SUM(total), 0) as ca FROM commandes WHERE statut != 'annulee'"
        )->fetch()['ca'];

        $nb  = $this->db->query("SELECT COUNT(*) as nb FROM commandes")->fetch()['nb'];
        $enA = $this->db->query(
            "SELECT COUNT(*) as nb FROM commandes WHERE statut = 'en_attente'"
        )->fetch()['nb'];

        // Meilleur produit (Feature Envy : logique produit dans CommandeManager)
        $top = $this->db->query(
            "SELECT p.nom, SUM(cl.quantite) as total_vendu
             FROM commande_lignes cl
             JOIN produits p ON p.id = cl.produit_id
             JOIN commandes c ON c.id = cl.commande_id
             WHERE c.statut != 'annulee'
             GROUP BY p.id ORDER BY total_vendu DESC LIMIT 1"
        )->fetch(PDO::FETCH_ASSOC);

        // CA du mois (logique rapport dans CommandeManager)
        $cam = $this->db->query(
            "SELECT COALESCE(SUM(total), 0) as ca FROM commandes
             WHERE strftime('%Y-%m', date_commande) = strftime('%Y-%m', 'now')
             AND statut != 'annulee'"
        )->fetch()['ca'];

        return [
            'ca_total'    => $ca,
            'ca_mois'     => $cam,
            'nb_commandes'=> $nb,
            'en_attente'  => $enA,
            'top_produit' => $top,
        ];
    }

    // Générer un PDF de facture — dépendance directe à TCPDF ou équivalent
    // Pour l'instant retourne du HTML
    public function genererFacture($cmdId) {
        $cmd    = $this->getCommande($cmdId);
        $lignes = $this->getLignes($cmdId);
        $u      = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $u->execute([$cmd['user_id']]);
        $user   = $u->fetch(PDO::FETCH_ASSOC);

        $html  = '<html><body>';
        $html .= '<h1>FACTURE - ' . $cmd['ref'] . '</h1>';
        $html .= '<p>' . $user['prenom'] . ' ' . $user['nom'] . '<br>';
        $html .= $user['adresse'] . '<br>' . $user['cp'] . ' ' . $user['ville'] . '</p>';
        $html .= '<table><tr><th>Produit</th><th>Qté</th><th>PU HT</th><th>Total HT</th></tr>';
        foreach ($lignes as $l) {
            $puHt  = $l['prix_unitaire'] / 1.20;
            $totHt = $puHt * $l['quantite'];
            $html .= '<tr><td>' . $l['nom'] . '</td><td>' . $l['quantite'] . '</td>'
                   . '<td>' . number_format($puHt, 2) . '€</td>'
                   . '<td>' . number_format($totHt, 2) . '€</td></tr>';
        }
        $html .= '</table>';
        $html .= '<p>Total HT : ' . number_format($cmd['total_ht'], 2) . ' €</p>';
        $html .= '<p>TVA 20% : ' . number_format($cmd['tva_montant'], 2) . ' €</p>';
        $html .= '<p>Total TTC : ' . number_format($cmd['total'], 2) . ' €</p>';
        $html .= '</body></html>';
        return $html;
    }

    // Recherche commandes — pour la page admin
    public function rechercher($filtres = []) {
        $where = ['1=1'];
        $params = [];
        if (!empty($filtres['statut'])) {
            $where[] = 'c.statut = ?';
            $params[] = $filtres['statut'];
        }
        if (!empty($filtres['ref'])) {
            $where[] = 'c.ref LIKE ?';
            $params[] = '%' . $filtres['ref'] . '%';
        }
        if (!empty($filtres['user_email'])) {
            $where[] = 'u.email LIKE ?';
            $params[] = '%' . $filtres['user_email'] . '%';
        }
        if (!empty($filtres['date_debut'])) {
            $where[] = "date(c.date_commande) >= ?";
            $params[] = $filtres['date_debut'];
        }
        if (!empty($filtres['date_fin'])) {
            $where[] = "date(c.date_commande) <= ?";
            $params[] = $filtres['date_fin'];
        }
        $sql = "SELECT c.*, u.nom, u.prenom, u.email
                FROM commandes c
                LEFT JOIN users u ON u.id = c.user_id
                WHERE " . implode(' AND ', $where) . "
                ORDER BY c.date_commande DESC";
        $s = $this->db->prepare($sql);
        $s->execute($params);
        return $s->fetchAll(PDO::FETCH_ASSOC);
    }
}
