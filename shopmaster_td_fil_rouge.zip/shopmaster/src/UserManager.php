<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

class UserManager
{
    private $db;

    public function __construct() {
        global $db;
        $this->db = $db;
        session_start();
    }

    // Inscription d'un nouvel utilisateur
    // Responsabilité 1 : validation
    // Responsabilité 2 : persistence
    // Responsabilité 3 : envoi d'email
    // Responsabilité 4 : gestion de session
    public function inscrire($data) {
        // Validation — tout dans la même méthode
        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'msg' => 'Email invalide'];
        }
        if (empty($data['mdp']) || strlen($data['mdp']) < 6) {
            return ['ok' => false, 'msg' => 'Mot de passe trop court (6 caractères min)'];
        }
        if ($data['mdp'] !== $data['mdp2']) {
            return ['ok' => false, 'msg' => 'Les mots de passe ne correspondent pas'];
        }
        if (empty($data['nom']) || empty($data['prenom'])) {
            return ['ok' => false, 'msg' => 'Nom et prénom obligatoires'];
        }

        // Vérifier si l'email existe déjà
        $s = $this->db->prepare("SELECT id FROM users WHERE email = ?");
        $s->execute([$data['email']]);
        if ($s->fetch()) {
            return ['ok' => false, 'msg' => 'Cet email est déjà utilisé'];
        }

        // Créer le compte
        $hash = password_hash($data['mdp'], PASSWORD_BCRYPT);
        $stmt = $this->db->prepare(
            "INSERT INTO users (nom, prenom, email, mdp, role, date_inscription)
             VALUES (?, ?, ?, ?, 'client', datetime('now'))"
        );
        $stmt->execute([
            nettoyer($data['nom']),
            nettoyer($data['prenom']),
            strtolower(trim($data['email'])),
            $hash,
        ]);
        $uid = $this->db->lastInsertId();

        // Email de bienvenue — directement dans la même méthode
        $corps = '<html><body>'
               . '<h2>Bienvenue sur ShopMaster !</h2>'
               . '<p>Bonjour ' . htmlspecialchars($data['prenom']) . ',</p>'
               . '<p>Votre compte a bien été créé. Vous pouvez maintenant commander.</p>'
               . '<p><a href="' . SITE_URL . '/connexion">Se connecter</a></p>'
               . '</body></html>';
        mail(
            $data['email'],
            'Bienvenue sur ShopMaster',
            $corps,
            'From: ' . EMAIL_FROM . "\r\nContent-Type: text/html; charset=UTF-8"
        );

        // Connecter automatiquement après inscription
        $_SESSION['user_id'] = $uid;
        $_SESSION['role']    = 'client';
        $_SESSION['nom']     = $data['nom'];
        $_SESSION['prenom']  = $data['prenom'];

        return ['ok' => true, 'user_id' => $uid];
    }

    public function connecter($email, $mdp) {
        $s = $this->db->prepare("SELECT * FROM users WHERE email = ? AND actif = 1");
        $s->execute([strtolower(trim($email))]);
        $user = $s->fetch(PDO::FETCH_ASSOC);

        if (!$user || !password_verify($mdp, $user['mdp'])) {
            // Log la tentative — directement ici
            logErreur('Tentative de connexion échouée', $email);
            return ['ok' => false, 'msg' => 'Email ou mot de passe incorrect'];
        }

        // Mettre à jour la dernière connexion
        $this->db->prepare(
            "UPDATE users SET derniere_connexion = datetime('now') WHERE id = ?"
        )->execute([$user['id']]);

        // Initialiser la session — mélange auth + session management
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role']    = $user['role'];
        $_SESSION['nom']     = $user['nom'];
        $_SESSION['prenom']  = $user['prenom'];
        $_SESSION['email']   = $user['email'];

        return ['ok' => true, 'user' => $user];
    }

    public function deconnecter() {
        session_unset();
        session_destroy();
    }

    // Récupère un user + ses commandes + ses stats — Feature Envy sur CommandeManager
    public function getProfil($uid) {
        $s = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $s->execute([$uid]);
        $user = $s->fetch(PDO::FETCH_ASSOC);
        if (!$user) return null;
        unset($user['mdp']); // Ne pas exposer le hash

        // Charger les commandes — logique qui devrait être dans CommandeManager
        $c = $this->db->prepare(
            "SELECT id, ref, statut, total, date_commande FROM commandes
             WHERE user_id = ? ORDER BY date_commande DESC LIMIT 5"
        );
        $c->execute([$uid]);
        $user['commandes_recentes'] = $c->fetchAll(PDO::FETCH_ASSOC);

        // Calculer des stats — logique métier dans UserManager
        $stats = $this->db->prepare(
            "SELECT COUNT(*) as nb, COALESCE(SUM(total), 0) as total_depense
             FROM commandes WHERE user_id = ? AND statut != 'annulee'"
        );
        $stats->execute([$uid]);
        $user['stats'] = $stats->fetch(PDO::FETCH_ASSOC);

        return $user;
    }

    public function majProfil($uid, $data) {
        $champs = [];
        $vals   = [];
        if (!empty($data['nom']))    { $champs[] = 'nom = ?';    $vals[] = nettoyer($data['nom']); }
        if (!empty($data['prenom'])) { $champs[] = 'prenom = ?'; $vals[] = nettoyer($data['prenom']); }
        if (!empty($data['tel']))    { $champs[] = 'tel = ?';    $vals[] = nettoyer($data['tel']); }
        if (!empty($data['adresse'])){ $champs[] = 'adresse = ?';$vals[] = nettoyer($data['adresse']); }
        if (!empty($data['ville']))  { $champs[] = 'ville = ?';  $vals[] = nettoyer($data['ville']); }
        if (!empty($data['cp']))     { $champs[] = 'cp = ?';     $vals[] = nettoyer($data['cp']); }
        if (empty($champs)) return false;
        $vals[] = $uid;
        $this->db->prepare(
            "UPDATE users SET " . implode(', ', $champs) . " WHERE id = ?"
        )->execute($vals);
        return true;
    }

    public function changerMdp($uid, $ancien, $nouveau) {
        $s = $this->db->prepare("SELECT mdp FROM users WHERE id = ?");
        $s->execute([$uid]);
        $user = $s->fetch(PDO::FETCH_ASSOC);

        if (!password_verify($ancien, $user['mdp'])) {
            return ['ok' => false, 'msg' => 'Ancien mot de passe incorrect'];
        }
        if (strlen($nouveau) < 6) {
            return ['ok' => false, 'msg' => 'Nouveau mot de passe trop court'];
        }

        $this->db->prepare("UPDATE users SET mdp = ? WHERE id = ?")
                 ->execute([password_hash($nouveau, PASSWORD_BCRYPT), $uid]);

        // Email de confirmation de changement de mdp — directement ici
        $s2 = $this->db->prepare("SELECT email, prenom FROM users WHERE id = ?");
        $s2->execute([$uid]);
        $u2 = $s2->fetch(PDO::FETCH_ASSOC);
        mail(
            $u2['email'],
            '[ShopMaster] Votre mot de passe a été modifié',
            '<p>Bonjour ' . $u2['prenom'] . ', votre mot de passe vient d\'être modifié.</p>',
            'From: ' . EMAIL_FROM . "\r\nContent-Type: text/html; charset=UTF-8"
        );

        return ['ok' => true];
    }

    // Réinitialisation mot de passe — encore une responsabilité
    public function demanderReinitialisationMdp($email) {
        $s = $this->db->prepare("SELECT * FROM users WHERE email = ? AND actif = 1");
        $s->execute([$email]);
        $user = $s->fetch(PDO::FETCH_ASSOC);
        if (!$user) return false;

        $token   = bin2hex(random_bytes(32));
        $expiry  = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // Stocker le token dans les notes de l'utilisateur — solution temporaire jamais corrigée
        $this->db->prepare("UPDATE users SET notes = ? WHERE id = ?")
                 ->execute(['reset:' . $token . ':' . $expiry, $user['id']]);

        $lien  = SITE_URL . '/reset-password?token=' . $token;
        $corps = '<p>Cliquez ici pour réinitialiser votre mot de passe : <a href="' . $lien . '">'
               . $lien . '</a></p><p>Ce lien expire dans 1 heure.</p>';
        mail($email, '[ShopMaster] Réinitialisation de mot de passe', $corps,
             'From: ' . EMAIL_FROM . "\r\nContent-Type: text/html; charset=UTF-8");
        return true;
    }

    // Liste tous les utilisateurs pour l'admin
    public function lister($filtre = '') {
        if ($filtre) {
            $s = $this->db->prepare(
                "SELECT id, nom, prenom, email, role, actif, date_inscription,
                        nb_commandes, total_achats
                 FROM users WHERE nom LIKE ? OR prenom LIKE ? OR email LIKE ?
                 ORDER BY date_inscription DESC"
            );
            $f = '%' . $filtre . '%';
            $s->execute([$f, $f, $f]);
        } else {
            $s = $this->db->query(
                "SELECT id, nom, prenom, email, role, actif, date_inscription,
                        nb_commandes, total_achats
                 FROM users ORDER BY date_inscription DESC"
            );
        }
        return $s->fetchAll(PDO::FETCH_ASSOC);
    }
}
