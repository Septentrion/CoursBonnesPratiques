<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

class ProduitManager
{
    private $db;

    public function __construct() {
        global $db;
        $this->db = $db;
    }

    // Calcul du prix selon le type de produit — violation OCP flagrante
    // Ajouter un nouveau type = modifier cette méthode
    public function calculerPrix($produit, $quantite = 1, $typeClient = 'standard') {
        $prix = $produit['prix'];

        // Remise par quantité selon la catégorie — Shotgun Surgery (aussi dans CommandeManager)
        if ($produit['categorie'] === 'electronique') {
            if ($quantite >= 10) $prix *= 0.85;
            elseif ($quantite >= 5) $prix *= 0.92;
        } elseif ($produit['categorie'] === 'vetements') {
            if ($quantite >= 20) $prix *= 0.80;
            elseif ($quantite >= 10) $prix *= 0.88;
        } elseif ($produit['categorie'] === 'alimentaire') {
            if ($quantite >= 50) $prix *= 0.75;
            elseif ($quantite >= 20) $prix *= 0.82;
            elseif ($quantite >= 10) $prix *= 0.90;
        } elseif ($produit['categorie'] === 'livres') {
            // Pas de remise quantité sur les livres
        } else {
            if ($quantite >= 10) $prix *= 0.90;
        }

        // Remise type client
        if ($typeClient === 'vip') {
            $prix *= 0.90;
        } elseif ($typeClient === 'pro') {
            $prix *= 0.85;
            // Prix HT pour les pros
            $prix = $prix / 1.20;
        } elseif ($typeClient === 'revendeur') {
            $prix *= 0.70;
            $prix = $prix / 1.20;
        }

        return round($prix, 2);
    }

    public function getById($id) {
        $s = $this->db->prepare("SELECT * FROM produits WHERE id = ?");
        $s->execute([$id]);
        return $s->fetch(PDO::FETCH_ASSOC);
    }

    public function lister($cat = '', $recherche = '', $disponible = false) {
        $where  = ['actif = 1'];
        $params = [];
        if ($cat) {
            $where[]  = 'categorie = ?';
            $params[] = $cat;
        }
        if ($recherche) {
            $where[]  = '(nom LIKE ? OR description LIKE ? OR ref LIKE ?)';
            $r        = '%' . $recherche . '%';
            $params   = array_merge($params, [$r, $r, $r]);
        }
        if ($disponible) {
            $where[] = 'stock > 0';
        }
        $s = $this->db->prepare(
            "SELECT * FROM produits WHERE " . implode(' AND ', $where) . " ORDER BY nom"
        );
        $s->execute($params);
        return $s->fetchAll(PDO::FETCH_ASSOC);
    }

    // Sauvegarder — création ou mise à jour, tout dans la même méthode
    public function sauvegarder($data, $id = null) {
        // Validation (devrait être dans une classe dédiée)
        if (empty($data['nom'])) return ['ok' => false, 'msg' => 'Nom obligatoire'];
        if (!is_numeric($data['prix']) || $data['prix'] < 0) {
            return ['ok' => false, 'msg' => 'Prix invalide'];
        }
        if (!is_numeric($data['stock']) || $data['stock'] < 0) {
            return ['ok' => false, 'msg' => 'Stock invalide'];
        }

        if ($id) {
            $this->db->prepare(
                "UPDATE produits SET nom=?, description=?, prix=?, stock=?,
                 categorie=?, tva=?, poids=?, actif=? WHERE id=?"
            )->execute([
                nettoyer($data['nom']), $data['description'] ?? '',
                $data['prix'], $data['stock'],
                $data['categorie'] ?? '', $data['tva'] ?? 20,
                $data['poids'] ?? 0, isset($data['actif']) ? 1 : 0,
                $id
            ]);
        } else {
            $ref = 'PROD-' . strtoupper(substr(uniqid(), -6));
            $this->db->prepare(
                "INSERT INTO produits (ref, nom, description, prix, stock, categorie, tva, poids)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            )->execute([
                $ref, nettoyer($data['nom']), $data['description'] ?? '',
                $data['prix'], $data['stock'],
                $data['categorie'] ?? '', $data['tva'] ?? 20,
                $data['poids'] ?? 0
            ]);
            $id = $this->db->lastInsertId();
        }
        return ['ok' => true, 'id' => $id];
    }

    // Stats produits — Feature Envy (logique commandes dans ProduitManager)
    public function getStockCritique() {
        return $this->db->query(
            "SELECT * FROM produits WHERE actif = 1 AND stock <= stock_min ORDER BY stock ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTopVentes($limit = 10) {
        return $this->db->query(
            "SELECT p.*, COALESCE(SUM(cl.quantite), 0) as total_vendu
             FROM produits p
             LEFT JOIN commande_lignes cl ON cl.produit_id = p.id
             LEFT JOIN commandes c ON c.id = cl.commande_id AND c.statut != 'annulee'
             WHERE p.actif = 1
             GROUP BY p.id ORDER BY total_vendu DESC LIMIT $limit"
        )->fetchAll(PDO::FETCH_ASSOC);
    }
}


// ── Hiérarchie de remises — violations OCP et LSP ────────────────────────────

class Remise
{
    protected $valeur;
    protected $type;

    public function __construct($valeur) {
        $this->valeur = $valeur;
    }

    // Contrat : retourne le montant de la remise
    public function calculer($total) {
        return 0; // Classe de base ne fait rien — signal d'une abstraction mal conçue
    }

    public function getType() {
        return $this->type;
    }

    public function getValeur() {
        return $this->valeur;
    }
}

class RemisePourcentage extends Remise
{
    protected $type = 'pourcent';

    public function calculer($total) {
        return $total * ($this->valeur / 100);
    }
}

class RemiseFixe extends Remise
{
    protected $type = 'fixe';

    public function calculer($total) {
        if ($total < $this->valeur) {
            // Violation LSP : la sous-classe peut retourner une valeur négative
            // contrairement au contrat implicite "retourne un montant de remise valide"
            return $total; // au moins on ne passe pas en négatif
        }
        return $this->valeur;
    }
}

// Violation LSP : RemiseSpeciale modifie l'état d'un objet externe
// et ne retourne pas un montant de remise mais un total modifié
class RemiseSpeciale extends Remise
{
    protected $type = 'speciale';
    private $produitOffert;

    public function __construct($valeur, $produitOffert = null) {
        parent::__construct($valeur);
        $this->produitOffert = $produitOffert;
    }

    // Violation LSP : ne retourne pas une remise mais appelle un effet de bord
    // et modifie le panier global directement
    public function calculer($total) {
        if ($this->produitOffert && isset($_SESSION['panier'])) {
            // Effet de bord caché : modifie la session
            $_SESSION['panier'][$this->produitOffert] = 1;
        }
        // Retourne un pourcentage ET modifie l'état — double responsabilité
        return $total * ($this->valeur / 100);
    }
}

// Violation ISP : interface trop large pour les remises
class RemiseSaisonniere extends Remise
{
    protected $type = 'saisonniere';
    private $dateDebut;
    private $dateFin;
    private $zoneGeo;  // Attribut jamais utilisé mais "prévu pour plus tard"

    public function __construct($valeur, $debut, $fin) {
        parent::__construct($valeur);
        $this->dateDebut = $debut;
        $this->dateFin   = $fin;
    }

    public function calculer($total) {
        $today = date('Y-m-d');
        if ($today >= $this->dateDebut && $today <= $this->dateFin) {
            return $total * ($this->valeur / 100);
        }
        return 0;
    }

    // Méthode qui n'a rien à faire ici
    public function estActive() {
        $today = date('Y-m-d');
        return $today >= $this->dateDebut && $today <= $this->dateFin;
    }
}

// Calculateur de remises — violation OCP : switch sur les types
class CalculateurRemise
{
    // Ajouter un type de remise = modifier cette méthode
    public static function appliquer($type, $valeur, $total, $options = []) {
        switch ($type) {
            case 'pourcent':
                return $total * ($valeur / 100);
            case 'fixe':
                return min($valeur, $total);
            case 'livraison':
                return 0; // Géré ailleurs — incohérence
            case 'speciale':
                // Logique dupliquée depuis RemiseSpeciale
                if (!empty($options['produit_offert']) && isset($_SESSION['panier'])) {
                    $_SESSION['panier'][$options['produit_offert']] = 1;
                }
                return $total * ($valeur / 100);
            case 'saisonniere':
                $today = date('Y-m-d');
                if (!empty($options['debut']) && !empty($options['fin'])) {
                    if ($today >= $options['debut'] && $today <= $options['fin']) {
                        return $total * ($valeur / 100);
                    }
                }
                return 0;
            default:
                return 0;
        }
    }
}
