<?php

session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/src/helpers.php';
require_once __DIR__ . '/src/CommandeManager.php';
require_once __DIR__ . '/src/UserManager.php';
require_once __DIR__ . '/src/ProduitManager.php';
require_once __DIR__ . '/src/RapportManager.php';

$um = new UserManager();
$cm = new CommandeManager();
$pm = new ProduitManager();

$action = $_GET['action'] ?? 'accueil';
$id     = (int)($_GET['id'] ?? 0);

// Routeur artisanal — tout dans un seul switch
switch ($action) {

    case 'accueil':
        $prods = $pm->lister('', '', true);
        $titre = 'Accueil';
        // Mélange de logique dans le routeur
        $prodsParCategorie = [];
        foreach ($prods as $p) {
            $prodsParCategorie[$p['categorie']][] = $p;
        }
        include __DIR__ . '/templates/accueil.php';
        break;

    case 'produit':
        if (!$id) { header('Location: ?action=accueil'); exit; }
        $prod = $pm->getById($id);
        if (!$prod || !$prod['actif']) { echo '404'; exit; }
        $titre = $prod['nom'];
        include __DIR__ . '/templates/produit.php';
        break;

    case 'panier':
        // Logique panier directement dans le routeur
        if (!isset($_SESSION['panier'])) $_SESSION['panier'] = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pid = (int)($_POST['produit_id'] ?? 0);
            $qte = (int)($_POST['qte'] ?? 1);
            if ($pid > 0 && $qte > 0) {
                $p = $pm->getById($pid);
                if ($p && $p['stock'] >= $qte) {
                    $_SESSION['panier'][$pid] = ($_SESSION['panier'][$pid] ?? 0) + $qte;
                    $_SESSION['msg'] = 'Produit ajouté au panier';
                } else {
                    $_SESSION['err'] = 'Stock insuffisant';
                }
            }
            header('Location: ?action=panier'); exit;
        }
        // Calculer le total panier ici — logique métier dans le routeur
        $totalPanier = 0;
        $lignesPanier = [];
        foreach ($_SESSION['panier'] as $pid => $qte) {
            $p = $pm->getById($pid);
            if ($p) {
                $lignesPanier[] = ['prod' => $p, 'qte' => $qte, 'total' => $p['prix'] * $qte];
                $totalPanier += $p['prix'] * $qte;
            }
        }
        $fp = fraisPort($totalPanier);
        include __DIR__ . '/templates/panier.php';
        break;

    case 'commander':
        if (!estConnecte()) { header('Location: ?action=connexion'); exit; }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $res = $cm->creerCommande(
                $_SESSION['user_id'],
                $_SESSION['panier'] ?? [],
                [
                    'adresse'        => $_POST['adresse']        ?? '',
                    'ville'          => $_POST['ville']          ?? '',
                    'cp'             => $_POST['cp']             ?? '',
                    'pays'           => $_POST['pays']           ?? 'FR',
                    'mode_livraison' => $_POST['mode_livraison'] ?? 'standard',
                ],
                $_POST['mode_paiement'] ?? 'carte',
                $_POST['code_promo']    ?? ''
            );
            if ($res['ok']) {
                $_SESSION['panier'] = [];
                header('Location: ?action=confirmation&ref=' . $res['ref']); exit;
            } else {
                $_SESSION['err'] = $res['msg'];
                header('Location: ?action=panier'); exit;
            }
        }
        include __DIR__ . '/templates/checkout.php';
        break;

    case 'connexion':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $res = $um->connecter($_POST['email'] ?? '', $_POST['mdp'] ?? '');
            if ($res['ok']) {
                header('Location: ?action=mon-compte'); exit;
            } else {
                $erreurConnexion = $res['msg'];
            }
        }
        include __DIR__ . '/templates/connexion.php';
        break;

    case 'inscription':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $res = $um->inscrire($_POST);
            if ($res['ok']) {
                header('Location: ?action=mon-compte'); exit;
            } else {
                $erreur = $res['msg'];
            }
        }
        include __DIR__ . '/templates/inscription.php';
        break;

    case 'deconnexion':
        $um->deconnecter();
        header('Location: ?action=accueil'); exit;

    case 'mon-compte':
        if (!estConnecte()) { header('Location: ?action=connexion'); exit; }
        $profil = $um->getProfil($_SESSION['user_id']);
        include __DIR__ . '/templates/mon-compte.php';
        break;

    case 'commande':
        if (!estConnecte()) { header('Location: ?action=connexion'); exit; }
        $cmd = $cm->getCommande($id);
        if (!$cmd || $cmd['user_id'] != $_SESSION['user_id']) {
            echo 'Commande introuvable'; exit;
        }
        $lignes = $cm->getLignes($id);
        include __DIR__ . '/templates/commande_detail.php';
        break;

    // ── Zone admin (sans vrai contrôle d'accès centralisé) ───────────────────

    case 'admin':
        if (!estAdmin()) { echo 'Accès refusé'; exit; }
        $stats = $cm->getStats();
        include __DIR__ . '/templates/admin/dashboard.php';
        break;

    case 'admin-commandes':
        if (!estAdmin()) { echo 'Accès refusé'; exit; }
        $filtres  = [
            'statut'      => $_GET['statut']      ?? '',
            'ref'         => $_GET['ref']         ?? '',
            'user_email'  => $_GET['email']       ?? '',
            'date_debut'  => $_GET['date_debut']  ?? '',
            'date_fin'    => $_GET['date_fin']    ?? '',
        ];
        $commandes = $cm->rechercher($filtres);
        include __DIR__ . '/templates/admin/commandes.php';
        break;

    case 'admin-statut':
        if (!estAdmin()) { echo 'Accès refusé'; exit; }
        if ($id && !empty($_POST['statut'])) {
            $ok = $cm->changerStatut($id, $_POST['statut']);
            echo $ok ? 'ok' : 'erreur';
        }
        break;

    case 'admin-produits':
        if (!estAdmin()) { echo 'Accès refusé'; exit; }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $res = $pm->sauvegarder($_POST, $id ?: null);
            if ($res['ok']) {
                header('Location: ?action=admin-produits'); exit;
            }
        }
        $produits = $pm->lister();
        $critique = $pm->getStockCritique();
        include __DIR__ . '/templates/admin/produits.php';
        break;

    case 'admin-rapport':
        if (!estAdmin()) { echo 'Accès refusé'; exit; }
        $rm    = new RapportManager();
        $annee = (int)($_GET['annee'] ?? date('Y'));
        $mois  = (int)($_GET['mois']  ?? date('n'));
        // Générer directement sans vérification — bloque la page pendant le calcul
        $rapport = $rm->genererRapportMensuel($annee, $mois);
        include __DIR__ . '/templates/admin/rapport.php';
        break;

    default:
        http_response_code(404);
        echo '<h1>Page introuvable</h1>';
}
